# DineDesk - Restaurant Ordering Platform

Online orders, table reservations, digital menu, payments (demo) and a live kitchen dashboard.

**Stack:** Next.js 14 (App Router) · Tailwind CSS · Node.js + Express · PostgreSQL · Socket.io · JWT

## Roles

| Role | Can do |
|---|---|
| Customer | View menu, place orders, track status live, reserve tables, pay (demo) |
| Kitchen | Live kitchen dashboard, update order status |
| Admin | Menu CRUD, view all orders and reservations, daily stats, plus kitchen access |

## Folder structure

```
dinedesk/
├── backend/
│   ├── server.js            # Express + Socket.io entry
│   ├── db.js                # PostgreSQL pool
│   ├── schema.sql           # Tables
│   ├── seed.js              # Demo users + menu
│   ├── middleware/auth.js   # JWT + role check
│   └── routes/              # auth, menu, orders, reservations
└── frontend/
    └── app/
        ├── layout.js, page.js, globals.css
        ├── components/Navbar.js
        ├── lib/api.js
        └── login | register | menu | orders | reserve | kitchen | admin
```

## Setup

### 1. Prerequisites
Node.js 18+ and PostgreSQL installed.

### 2. Database
```bash
psql -U postgres -c "CREATE DATABASE dinedesk;"
psql -U postgres -d dinedesk -f backend/schema.sql
```

### 3. Backend
```bash
cd backend
npm install
cp .env.example .env      # Windows: copy .env.example .env
# edit .env -> set your postgres password in DATABASE_URL
npm run seed              # creates demo users and menu items
npm run dev               # http://localhost:5000
```

### 4. Frontend (new terminal)
```bash
cd frontend
npm install
cp .env.local.example .env.local
npm run dev               # http://localhost:3000
```

## Demo logins (after seed)

| Role | Email | Password |
|---|---|---|
| Admin | admin@dinedesk.com | admin123 |
| Kitchen | kitchen@dinedesk.com | kitchen123 |
| Customer | customer@dinedesk.com | customer123 |

## Test flow

1. Open the site in two browser windows.
2. Window A: login as customer, open Menu, add items, enter table number, place order.
3. Window B: login as kitchen, the order appears instantly on /kitchen.
4. Click "Mark preparing" then "Mark ready". Window A's My Orders page updates live.
5. Login as admin to manage menu items and see stats.

## API summary

| Method | Endpoint | Access |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | Public |
| GET | /api/menu | Public |
| GET/POST/PUT/DELETE | /api/menu, /api/menu/:id | Admin |
| POST | /api/orders | Logged in |
| GET | /api/orders/mine | Customer |
| GET | /api/orders/active | Kitchen/Admin |
| PATCH | /api/orders/:id/status | Kitchen/Admin |
| POST | /api/orders/:id/pay | Owner/Admin |
| GET | /api/orders, /api/orders/stats/summary | Admin |
| POST | /api/reservations | Logged in |
| GET | /api/reservations/mine | Logged in |
| PATCH | /api/reservations/:id/cancel | Owner/Admin |
| GET | /api/reservations | Admin |

## Adding real payments (Razorpay)

1. `cd backend && npm i razorpay`
2. Create a Razorpay order on the server after the order is placed.
3. Open Razorpay Checkout in the frontend with the returned order id.
4. Verify the payment signature on the server, then set `payment_status='paid'`.

The current `/api/orders/:id/pay` route is a demo that marks the order paid directly.

## Deployment

- Database: Neon or Supabase (copy the connection string to `DATABASE_URL`)
- Backend: Render or Railway (set `DATABASE_URL`, `JWT_SECRET`, `CLIENT_URL`)
- Frontend: Vercel (set `NEXT_PUBLIC_API_URL` to your backend URL)
