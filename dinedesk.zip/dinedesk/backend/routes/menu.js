const router = require('express').Router();
const pool = require('../db');
const { protect, allow } = require('../middleware/auth');

// Public: available menu items
router.get('/', async (req, res) => {
  const { rows } = await pool.query(
    'SELECT * FROM menu_items WHERE available = true ORDER BY category, name'
  );
  res.json(rows);
});

// Admin: all items (including unavailable)
router.get('/all', protect, allow('admin'), async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM menu_items ORDER BY category, name');
  res.json(rows);
});

router.post('/', protect, allow('admin'), async (req, res) => {
  const { name, description, price, category, image_url } = req.body;
  if (!name || price === undefined || Number(price) < 0)
    return res.status(400).json({ error: 'Name and valid price required' });
  const { rows } = await pool.query(
    `INSERT INTO menu_items(name,description,price,category,image_url)
     VALUES($1,$2,$3,$4,$5) RETURNING *`,
    [name, description || '', price, category || 'Others', image_url || null]
  );
  res.status(201).json(rows[0]);
});

router.put('/:id', protect, allow('admin'), async (req, res) => {
  const { name, description, price, category, image_url, available } = req.body;
  const { rows } = await pool.query(
    `UPDATE menu_items SET name=$1, description=$2, price=$3, category=$4,
       image_url=$5, available=$6 WHERE id=$7 RETURNING *`,
    [name, description, price, category, image_url || null, available ?? true, req.params.id]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Item not found' });
  res.json(rows[0]);
});

// Soft delete if the item was ever ordered, hard delete otherwise
router.delete('/:id', protect, allow('admin'), async (req, res) => {
  try {
    await pool.query('DELETE FROM menu_items WHERE id=$1', [req.params.id]);
    res.json({ message: 'Deleted' });
  } catch (e) {
    if (e.code === '23503') {
      await pool.query('UPDATE menu_items SET available=false WHERE id=$1', [req.params.id]);
      return res.json({ message: 'Item used in past orders, marked unavailable instead' });
    }
    res.status(500).json({ error: 'Delete failed' });
  }
});

module.exports = router;
