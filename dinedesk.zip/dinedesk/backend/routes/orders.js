const router = require('express').Router();
const pool = require('../db');
const { protect, allow } = require('../middleware/auth');

const STATUSES = ['pending', 'preparing', 'ready', 'served', 'cancelled'];

const ITEMS_AGG = `
  COALESCE(json_agg(json_build_object('name', m.name, 'qty', oi.quantity, 'price', oi.price))
    FILTER (WHERE oi.id IS NOT NULL), '[]') AS items`;

module.exports = (io) => {
  // Place an order (price is always read from DB, never trusted from client)
  router.post('/', protect, async (req, res) => {
    const { table_no, items } = req.body;
    if (!table_no || !Array.isArray(items) || items.length === 0)
      return res.status(400).json({ error: 'Table number and items required' });

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      let total = 0;
      const priced = [];
      for (const it of items) {
        const qty = parseInt(it.quantity, 10);
        if (!qty || qty < 1) throw new Error('Invalid quantity');
        const { rows } = await client.query(
          'SELECT price FROM menu_items WHERE id=$1 AND available=true',
          [it.menu_item_id]
        );
        if (!rows[0]) throw new Error('Item unavailable');
        const price = Number(rows[0].price);
        total += price * qty;
        priced.push({ menu_item_id: it.menu_item_id, quantity: qty, price });
      }
      const order = (
        await client.query(
          'INSERT INTO orders(user_id,table_no,total) VALUES($1,$2,$3) RETURNING *',
          [req.user.id, table_no, total]
        )
      ).rows[0];
      for (const it of priced) {
        await client.query(
          'INSERT INTO order_items(order_id,menu_item_id,quantity,price) VALUES($1,$2,$3,$4)',
          [order.id, it.menu_item_id, it.quantity, it.price]
        );
      }
      await client.query('COMMIT');
      io.emit('new-order', order);
      res.status(201).json(order);
    } catch (e) {
      await client.query('ROLLBACK');
      res.status(400).json({ error: e.message || 'Order failed' });
    } finally {
      client.release();
    }
  });

  // Customer: my orders with items
  router.get('/mine', protect, async (req, res) => {
    const { rows } = await pool.query(
      `SELECT o.*, ${ITEMS_AGG}
       FROM orders o
       LEFT JOIN order_items oi ON oi.order_id = o.id
       LEFT JOIN menu_items m ON m.id = oi.menu_item_id
       WHERE o.user_id = $1
       GROUP BY o.id ORDER BY o.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  });

  // Kitchen: active orders
  router.get('/active', protect, allow('kitchen', 'admin'), async (req, res) => {
    const { rows } = await pool.query(
      `SELECT o.*, ${ITEMS_AGG}
       FROM orders o
       LEFT JOIN order_items oi ON oi.order_id = o.id
       LEFT JOIN menu_items m ON m.id = oi.menu_item_id
       WHERE o.status IN ('pending','preparing','ready')
       GROUP BY o.id ORDER BY o.created_at`
    );
    res.json(rows);
  });

  // Admin: all orders
  router.get('/', protect, allow('admin'), async (req, res) => {
    const { rows } = await pool.query(
      `SELECT o.*, u.name AS customer, ${ITEMS_AGG}
       FROM orders o
       LEFT JOIN users u ON u.id = o.user_id
       LEFT JOIN order_items oi ON oi.order_id = o.id
       LEFT JOIN menu_items m ON m.id = oi.menu_item_id
       GROUP BY o.id, u.name ORDER BY o.created_at DESC LIMIT 100`
    );
    res.json(rows);
  });

  // Admin: simple sales summary
  router.get('/stats/summary', protect, allow('admin'), async (req, res) => {
    const { rows } = await pool.query(
      `SELECT
         COUNT(*) FILTER (WHERE created_at::date = CURRENT_DATE)::int AS orders_today,
         COALESCE(SUM(total) FILTER (WHERE created_at::date = CURRENT_DATE AND status <> 'cancelled'), 0)::float AS sales_today,
         COUNT(*) FILTER (WHERE status IN ('pending','preparing','ready'))::int AS active_orders
       FROM orders`
    );
    res.json(rows[0]);
  });

  // Kitchen/admin: update status
  router.patch('/:id/status', protect, allow('kitchen', 'admin'), async (req, res) => {
    const { status } = req.body;
    if (!STATUSES.includes(status)) return res.status(400).json({ error: 'Invalid status' });
    const { rows } = await pool.query('UPDATE orders SET status=$1 WHERE id=$2 RETURNING *', [
      status,
      req.params.id,
    ]);
    if (!rows[0]) return res.status(404).json({ error: 'Order not found' });
    io.emit('order-updated', rows[0]);
    res.json(rows[0]);
  });

  // Payment (demo). Replace body with Razorpay verification for production.
  router.post('/:id/pay', protect, async (req, res) => {
    const { rows } = await pool.query(
      `UPDATE orders SET payment_status='paid'
       WHERE id=$1 AND (user_id=$2 OR $3 = 'admin') RETURNING *`,
      [req.params.id, req.user.id, req.user.role]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Order not found' });
    io.emit('order-updated', rows[0]);
    res.json(rows[0]);
  });

  return router;
};
