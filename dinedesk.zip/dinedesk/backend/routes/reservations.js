const router = require('express').Router();
const pool = require('../db');
const { protect, allow } = require('../middleware/auth');

// Create reservation (blocks same table within a 2-hour window)
router.post('/', protect, async (req, res) => {
  const { table_no, guests, reserve_time } = req.body;
  if (!table_no || !guests || !reserve_time)
    return res.status(400).json({ error: 'Table, guests and time required' });
  if (new Date(reserve_time) < new Date())
    return res.status(400).json({ error: 'Choose a future time' });

  const clash = await pool.query(
    `SELECT 1 FROM reservations
     WHERE table_no=$1 AND status='booked'
       AND reserve_time > $2::timestamp - interval '2 hours'
       AND reserve_time < $2::timestamp + interval '2 hours'`,
    [table_no, reserve_time]
  );
  if (clash.rowCount) return res.status(400).json({ error: 'Table already booked at that time' });

  const { rows } = await pool.query(
    `INSERT INTO reservations(user_id,table_no,guests,reserve_time)
     VALUES($1,$2,$3,$4) RETURNING *`,
    [req.user.id, table_no, guests, reserve_time]
  );
  res.status(201).json(rows[0]);
});

router.get('/mine', protect, async (req, res) => {
  const { rows } = await pool.query(
    'SELECT * FROM reservations WHERE user_id=$1 ORDER BY reserve_time DESC',
    [req.user.id]
  );
  res.json(rows);
});

router.patch('/:id/cancel', protect, async (req, res) => {
  const { rows } = await pool.query(
    `UPDATE reservations SET status='cancelled'
     WHERE id=$1 AND (user_id=$2 OR $3='admin') RETURNING *`,
    [req.params.id, req.user.id, req.user.role]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Reservation not found' });
  res.json(rows[0]);
});

// Admin: all reservations
router.get('/', protect, allow('admin'), async (req, res) => {
  const { rows } = await pool.query(
    `SELECT r.*, u.name AS customer FROM reservations r
     LEFT JOIN users u ON u.id = r.user_id
     ORDER BY r.reserve_time DESC LIMIT 100`
  );
  res.json(rows);
});

module.exports = router;
