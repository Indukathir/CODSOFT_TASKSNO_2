// Run: npm run seed   (after schema.sql)
const bcrypt = require('bcryptjs');
const pool = require('./db');

const users = [
  ['Admin', 'admin@dinedesk.com', 'admin123', 'admin'],
  ['Kitchen Staff', 'kitchen@dinedesk.com', 'kitchen123', 'kitchen'],
  ['Demo Customer', 'customer@dinedesk.com', 'customer123', 'customer'],
];

const menu = [
  ['Paneer Tikka', 'Char-grilled cottage cheese with spices', 220, 'Starters'],
  ['Chicken 65', 'Crispy South Indian style fried chicken', 240, 'Starters'],
  ['Veg Spring Rolls', 'Crunchy rolls with vegetable filling', 160, 'Starters'],
  ['Chicken Biryani', 'Seeraga samba rice with tender chicken', 320, 'Main Course'],
  ['Veg Meals', 'Rice, sambar, rasam, poriyal, curd, papad', 180, 'Main Course'],
  ['Butter Chicken', 'Creamy tomato gravy with chicken', 340, 'Main Course'],
  ['Parotta (2 pcs)', 'Flaky layered flatbread', 60, 'Main Course'],
  ['Gulab Jamun', 'Warm milk dumplings in sugar syrup', 90, 'Desserts'],
  ['Ice Cream Sundae', 'Vanilla ice cream with chocolate sauce', 130, 'Desserts'],
  ['Filter Coffee', 'Traditional South Indian coffee', 40, 'Beverages'],
  ['Fresh Lime Soda', 'Sweet or salted', 60, 'Beverages'],
];

(async () => {
  try {
    for (const [name, email, pw, role] of users) {
      const hash = await bcrypt.hash(pw, 10);
      await pool.query(
        `INSERT INTO users(name,email,password,role) VALUES($1,$2,$3,$4)
         ON CONFLICT (email) DO NOTHING`,
        [name, email, hash, role]
      );
    }
    const { rows } = await pool.query('SELECT COUNT(*)::int AS c FROM menu_items');
    if (rows[0].c === 0) {
      for (const [name, description, price, category] of menu) {
        await pool.query(
          'INSERT INTO menu_items(name,description,price,category) VALUES($1,$2,$3,$4)',
          [name, description, price, category]
        );
      }
    }
    console.log('Seed complete.');
    console.log('admin@dinedesk.com / admin123');
    console.log('kitchen@dinedesk.com / kitchen123');
    console.log('customer@dinedesk.com / customer123');
  } catch (e) {
    console.error(e);
  } finally {
    await pool.end();
  }
})();
