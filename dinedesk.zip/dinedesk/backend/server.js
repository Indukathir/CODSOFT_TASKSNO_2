require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const CLIENT = process.env.CLIENT_URL || 'http://localhost:3000';

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: CLIENT } });

app.use(cors({ origin: CLIENT }));
app.use(express.json());

app.get('/', (req, res) => res.json({ app: 'DineDesk API', status: 'ok' }));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/menu', require('./routes/menu'));
app.use('/api/orders', require('./routes/orders')(io));
app.use('/api/reservations', require('./routes/reservations'));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Server error' });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`DineDesk API running on port ${PORT}`));
