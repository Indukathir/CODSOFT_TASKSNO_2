'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, getUser } from '../lib/api';

const EMPTY = { name: '', description: '', price: '', category: '' };

export default function Admin() {
  const [stats, setStats] = useState(null);
  const [menu, setMenu] = useState([]);
  const [orders, setOrders] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [form, setForm] = useState(EMPTY);
  const [editId, setEditId] = useState(null);
  const router = useRouter();

  const load = async () => {
    const [s, m, o, r] = await Promise.all([
      api('/orders/stats/summary'),
      api('/menu/all'),
      api('/orders'),
      api('/reservations'),
    ]);
    setStats(s);
    Array.isArray(m) && setMenu(m);
    Array.isArray(o) && setOrders(o);
    Array.isArray(r) && setReservations(r);
  };

  useEffect(() => {
    const u = getUser();
    if (!u || u.role !== 'admin') return router.push('/login');
    load();
  }, []);

  const save = async (e) => {
    e.preventDefault();
    const body = { ...form, price: Number(form.price) };
    if (editId) {
      const current = menu.find((m) => m.id === editId);
      await api(`/menu/${editId}`, 'PUT', { ...body, available: current.available });
    } else {
      await api('/menu', 'POST', body);
    }
    setForm(EMPTY);
    setEditId(null);
    load();
  };

  const toggle = async (m) => {
    await api(`/menu/${m.id}`, 'PUT', { ...m, available: !m.available });
    load();
  };

  const del = async (id) => {
    if (!confirm('Delete this item?')) return;
    await api(`/menu/${id}`, 'DELETE');
    load();
  };

  const startEdit = (m) => {
    setEditId(m.id);
    setForm({ name: m.name, description: m.description || '', price: m.price, category: m.category || '' });
  };

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>

      {stats && (
        <div className="grid sm:grid-cols-3 gap-4">
          <div className="card"><p className="text-sm text-gray-500">Orders today</p><p className="text-3xl font-bold">{stats.orders_today}</p></div>
          <div className="card"><p className="text-sm text-gray-500">Sales today</p><p className="text-3xl font-bold">₹{stats.sales_today}</p></div>
          <div className="card"><p className="text-sm text-gray-500">Active orders</p><p className="text-3xl font-bold">{stats.active_orders}</p></div>
        </div>
      )}

      <section className="grid lg:grid-cols-3 gap-6">
        <form onSubmit={save} className="card space-y-3 h-fit">
          <h2 className="font-bold text-lg">{editId ? 'Edit item' : 'Add menu item'}</h2>
          <input className="input" placeholder="Name" required value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input className="input" placeholder="Description" value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <input className="input" type="number" placeholder="Price" required value={form.price}
            onChange={(e) => setForm({ ...form, price: e.target.value })} />
          <input className="input" placeholder="Category (Starters, Main Course...)" value={form.category}
            onChange={(e) => setForm({ ...form, category: e.target.value })} />
          <button className="btn w-full">{editId ? 'Update' : 'Add'}</button>
          {editId && (
            <button type="button" className="text-sm underline" onClick={() => { setEditId(null); setForm(EMPTY); }}>
              Cancel edit
            </button>
          )}
        </form>

        <div className="lg:col-span-2 card overflow-x-auto">
          <h2 className="font-bold text-lg mb-2">Menu items</h2>
          <table className="w-full text-sm">
            <thead><tr className="text-left border-b"><th className="py-1">Name</th><th>Category</th><th>Price</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {menu.map((m) => (
                <tr key={m.id} className="border-b">
                  <td className="py-1">{m.name}</td>
                  <td>{m.category}</td>
                  <td>₹{Number(m.price).toFixed(0)}</td>
                  <td>
                    <button onClick={() => toggle(m)} className={m.available ? 'text-green-700' : 'text-red-600'}>
                      {m.available ? 'Available' : 'Hidden'}
                    </button>
                  </td>
                  <td className="space-x-2 text-right">
                    <button onClick={() => startEdit(m)} className="text-brand underline">Edit</button>
                    <button onClick={() => del(m.id)} className="text-red-600 underline">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="grid lg:grid-cols-2 gap-6">
        <div className="card overflow-x-auto">
          <h2 className="font-bold text-lg mb-2">Recent orders</h2>
          <table className="w-full text-sm">
            <thead><tr className="text-left border-b"><th>#</th><th>Customer</th><th>Table</th><th>Total</th><th>Status</th><th>Pay</th></tr></thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-b">
                  <td>{o.id}</td><td>{o.customer}</td><td>{o.table_no}</td>
                  <td>₹{Number(o.total).toFixed(0)}</td><td>{o.status}</td><td>{o.payment_status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="card overflow-x-auto">
          <h2 className="font-bold text-lg mb-2">Reservations</h2>
          <table className="w-full text-sm">
            <thead><tr className="text-left border-b"><th>Customer</th><th>Table</th><th>Guests</th><th>Time</th><th>Status</th></tr></thead>
            <tbody>
              {reservations.map((r) => (
                <tr key={r.id} className="border-b">
                  <td>{r.customer}</td><td>{r.table_no}</td><td>{r.guests}</td>
                  <td>{new Date(r.reserve_time).toLocaleString()}</td><td>{r.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
