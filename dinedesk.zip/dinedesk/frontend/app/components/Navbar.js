'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getUser, logout } from '../lib/api';

export default function Navbar() {
  const [user, setUser] = useState(null);
  const router = useRouter();

  useEffect(() => {
    const sync = () => setUser(getUser());
    sync();
    window.addEventListener('auth-changed', sync);
    return () => window.removeEventListener('auth-changed', sync);
  }, []);

  return (
    <nav className="bg-brand text-white">
      <div className="max-w-6xl mx-auto px-4 py-3 flex flex-wrap items-center gap-4">
        <Link href="/" className="font-extrabold text-xl mr-4">
          DineDesk
        </Link>
        <Link href="/menu" className="hover:underline">Menu</Link>
        {user && <Link href="/reserve" className="hover:underline">Reserve</Link>}
        {user && <Link href="/orders" className="hover:underline">My Orders</Link>}
        {user && ['kitchen', 'admin'].includes(user.role) && (
          <Link href="/kitchen" className="hover:underline">Kitchen</Link>
        )}
        {user?.role === 'admin' && <Link href="/admin" className="hover:underline">Admin</Link>}
        <div className="ml-auto flex items-center gap-3">
          {user ? (
            <>
              <span className="text-sm opacity-90">Hi, {user.name} ({user.role})</span>
              <button
                onClick={() => {
                  logout();
                  router.push('/');
                }}
                className="bg-white text-brand px-3 py-1 rounded-lg font-semibold"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="hover:underline">Login</Link>
              <Link href="/register" className="bg-white text-brand px-3 py-1 rounded-lg font-semibold">
                Register
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
