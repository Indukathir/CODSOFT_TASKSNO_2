'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { io } from 'socket.io-client';
import { api, getUser, API_URL } from '../lib/api';

const NEXT = { pending: 'preparing', preparing: 'ready', ready: 'served' };
const COLORS = {
  pending: 'bg-yellow-100 text-yellow-800',
  preparing: 'bg-blue-100 text-blue-800',
  ready: 'bg-green-100 text-green-800',
};

export default function Kitchen() {
  const [orders, setOrders] = useState([]);
  const router = useRouter();

  const load = () =>
    api('/orders/active').then((d) => Array.isArray(d) && setOrders(d));

  useEffect(() => {
    const u = getUser();
    if (!u || !['kitchen', 'admin'].includes(u.role)) return router.push('/login');
    load();
    const socket = io(API_URL);
    socket.on('new-order', load);
    socket.on('order-updated', load);
    return () => socket.disconnect();
  }, []);

  const advance = (o) => api(`/orders/${o.id}/status`, 'PATCH', { status: NEXT[o.status] });
  const cancel = (o) => api(`/orders/${o.id}/status`, 'PATCH', { status: 'cancelled' });

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Kitchen Dashboard</h1>
      {orders.length === 0 && <p className="text-gray-500">No active orders. New orders appear here live.</p>}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {orders.map((o) => (
          <div key={o.id} className="card">
            <div className="flex justify-between items-center">
              <h3 className="font-bold">#{o.id} · Table {o.table_no}</h3>
              <span className={`text-xs px-2 py-1 rounded-full font-semibold ${COLORS[o.status]}`}>
                {o.status}
              </span>
            </div>
            <ul className="my-3 text-sm space-y-1">
              {o.items.map((it, idx) => (
                <li key={idx}>{it.qty} × {it.name}</li>
              ))}
            </ul>
            <p className="text-xs text-gray-500 mb-3">
              {new Date(o.created_at).toLocaleTimeString()}
            </p>
            <div className="flex gap-2">
              <button onClick={() => advance(o)} className="btn flex-1">
                Mark {NEXT[o.status]}
              </button>
              {o.status === 'pending' && (
                <button onClick={() => cancel(o)} className="px-3 rounded-lg bg-red-100 text-red-700 font-semibold">
                  Cancel
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
