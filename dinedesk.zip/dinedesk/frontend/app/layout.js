import './globals.css';
import Navbar from './components/Navbar';

export const metadata = {
  title: 'DineDesk - Restaurant Ordering Platform',
  description: 'Online orders, table reservations and kitchen dashboard',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main className="max-w-6xl mx-auto p-4 md:p-6">{children}</main>
      </body>
    </html>
  );
}
