'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, saveAuth } from '../lib/api';

export default function Login() {
  const [f, setF] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const router = useRouter();

  const submit = async (e) => {
    e.preventDefault();
    const res = await api('/auth/login', 'POST', f);
    if (res.token) {
      saveAuth(res.token, res.user);
      router.push(res.user.role === 'kitchen' ? '/kitchen' : res.user.role === 'admin' ? '/admin' : '/menu');
    } else setError(res.error);
  };

  return (
    <form onSubmit={submit} className="card max-w-md mx-auto space-y-3 mt-8">
      <h1 className="text-2xl font-bold">Login</h1>
      {error && <p className="text-red-600 text-sm">{error}</p>}
      <input className="input" type="email" placeholder="Email" required
        onChange={(e) => setF({ ...f, email: e.target.value })} />
      <input className="input" type="password" placeholder="Password" required
        onChange={(e) => setF({ ...f, password: e.target.value })} />
      <button className="btn w-full">Login</button>
      <p className="text-xs text-gray-500">
        Demo: customer@dinedesk.com / customer123 &nbsp;|&nbsp; kitchen@dinedesk.com / kitchen123 &nbsp;|&nbsp; admin@dinedesk.com / admin123
      </p>
    </form>
  );
}
