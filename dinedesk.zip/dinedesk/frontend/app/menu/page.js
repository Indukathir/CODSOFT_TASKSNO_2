'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, getUser } from '../lib/api';

export default function Menu() {
  const [items, setItems] = useState([]);
  const [cart, setCart] = useState({});
  const [tableNo, setTableNo] = useState('');
  const [category, setCategory] = useState('All');
  const [msg, setMsg] = useState('');
  const router = useRouter();

  useEffect(() => {
    api('/menu').then((d) => Array.isArray(d) && setItems(d));
  }, []);

  const categories = ['All', ...new Set(items.map((i) => i.category).filter(Boolean))];
  const shown = category === 'All' ? items : items.filter((i) => i.category === category);

  const add = (id) => setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));
  const remove = (id) =>
    setCart((c) => {
      const n = { ...c };
      if ((n[id] || 0) <= 1) delete n[id];
      else n[id] -= 1;
      return n;
    });

  const total = items.reduce((s, i) => s + (cart[i.id] || 0) * Number(i.price), 0);

  const placeOrder = async () => {
    if (!getUser()) return router.push('/login');
    const orderItems = Object.entries(cart).map(([id, quantity]) => ({
      menu_item_id: Number(id),
      quantity,
    }));
    const res = await api('/orders', 'POST', { table_no: Number(tableNo), items: orderItems });
    if (res.id) {
      setCart({});
      setMsg(`Order #${res.id} placed! Redirecting to your orders...`);
      setTimeout(() => router.push('/orders'), 1200);
    } else setMsg(res.error || 'Could not place order');
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <div className="flex gap-2 flex-wrap mb-4">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`px-3 py-1 rounded-full text-sm border ${
                category === c ? 'bg-brand text-white border-brand' : 'bg-white'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {shown.map((i) => (
            <div key={i.id} className="card flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-lg">{i.name}</h3>
                <p className="text-sm text-gray-500">{i.description}</p>
                <p className="font-semibold mt-1">₹{Number(i.price).toFixed(0)}</p>
              </div>
              <div className="flex items-center gap-3 mt-3">
                <button onClick={() => remove(i.id)} className="px-3 py-1 bg-gray-200 rounded">-</button>
                <span className="w-6 text-center">{cart[i.id] || 0}</span>
                <button onClick={() => add(i.id)} className="px-3 py-1 bg-brand text-white rounded">+</button>
              </div>
            </div>
          ))}
          {shown.length === 0 && <p className="text-gray-500">No items yet.</p>}
        </div>
      </div>

      <div className="card h-fit lg:sticky lg:top-4 space-y-3">
        <h2 className="font-bold text-xl">Your Order</h2>
        {items.filter((i) => cart[i.id]).map((i) => (
          <div key={i.id} className="flex justify-between text-sm">
            <span>{cart[i.id]} × {i.name}</span>
            <span>₹{(cart[i.id] * Number(i.price)).toFixed(0)}</span>
          </div>
        ))}
        <input
          className="input" type="number" min="1" placeholder="Table number"
          value={tableNo} onChange={(e) => setTableNo(e.target.value)}
        />
        <p className="font-bold">Total: ₹{total.toFixed(0)}</p>
        <button className="btn-green w-full" disabled={!total || !tableNo} onClick={placeOrder}>
          Place Order
        </button>
        {msg && <p className="text-sm text-brand">{msg}</p>}
      </div>
    </div>
  );
}
