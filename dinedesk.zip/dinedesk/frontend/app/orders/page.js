'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { io } from 'socket.io-client';
import { api, getUser, API_URL } from '../lib/api';

const COLORS = {
  pending: 'bg-yellow-100 text-yellow-800',
  preparing: 'bg-blue-100 text-blue-800',
  ready: 'bg-green-100 text-green-800',
  served: 'bg-gray-200 text-gray-700',
  cancelled: 'bg-red-100 text-red-700',
};

export default function MyOrders() {
  const [orders, setOrders] = useState([]);
  const router = useRouter();

  const load = () =>
    api('/orders/mine').then((d) => Array.isArray(d) && setOrders(d));

  useEffect(() => {
    if (!getUser()) return router.push('/login');
    load();
    const socket = io(API_URL);
    socket.on('order-updated', load); // live status
    return () => socket.disconnect();
  }, []);

  const pay = async (id) => {
    await api(`/orders/${id}/pay`, 'POST');
    load();
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold">My Orders</h1>
      {orders.length === 0 && <p className="text-gray-500">No orders yet.</p>}
      {orders.map((o) => (
        <div key={o.id} className="card">
          <div className="flex justify-between items-center">
            <h3 className="font-bold">Order #{o.id} · Table {o.table_no}</h3>
            <span className={`text-xs px-2 py-1 rounded-full font-semibold ${COLORS[o.status]}`}>
              {o.status}
            </span>
          </div>
          <ul className="text-sm my-2">
            {o.items.map((it, idx) => (
              <li key={idx}>{it.qty} × {it.name}</li>
            ))}
          </ul>
          <div className="flex justify-between items-center">
            <span className="font-semibold">₹{Number(o.total).toFixed(0)} · {o.payment_status}</span>
            {o.payment_status === 'unpaid' && o.status !== 'cancelled' && (
              <button className="btn" onClick={() => pay(o.id)}>Pay Now (demo)</button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
