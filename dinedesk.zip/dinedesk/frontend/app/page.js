import Link from 'next/link';

export default function Home() {
  return (
    <div className="text-center py-16">
      <h1 className="text-5xl font-extrabold text-brand mb-4">DineDesk</h1>
      <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
        Explore the menu, place orders from your table, reserve a seat and track your food live.
      </p>
      <div className="flex justify-center gap-4 flex-wrap">
        <Link href="/menu" className="btn">View Menu</Link>
        <Link href="/reserve" className="btn-green">Reserve a Table</Link>
      </div>

      <div className="grid md:grid-cols-3 gap-4 mt-14 text-left">
        <div className="card">
          <h3 className="font-bold mb-1">Digital Menu</h3>
          <p className="text-sm text-gray-600">Browse by category and order straight from your table.</p>
        </div>
        <div className="card">
          <h3 className="font-bold mb-1">Live Tracking</h3>
          <p className="text-sm text-gray-600">See your order move from pending to ready in real time.</p>
        </div>
        <div className="card">
          <h3 className="font-bold mb-1">Kitchen Dashboard</h3>
          <p className="text-sm text-gray-600">Staff receive new orders instantly and update their status.</p>
        </div>
      </div>
    </div>
  );
}
