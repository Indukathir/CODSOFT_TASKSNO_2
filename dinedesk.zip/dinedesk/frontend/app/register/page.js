'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, saveAuth } from '../lib/api';

export default function Register() {
  const [f, setF] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const router = useRouter();

  const submit = async (e) => {
    e.preventDefault();
    const res = await api('/auth/register', 'POST', f);
    if (res.token) {
      saveAuth(res.token, res.user);
      router.push('/menu');
    } else setError(res.error);
  };

  return (
    <form onSubmit={submit} className="card max-w-md mx-auto space-y-3 mt-8">
      <h1 className="text-2xl font-bold">Create account</h1>
      {error && <p className="text-red-600 text-sm">{error}</p>}
      <input className="input" placeholder="Full name" required
        onChange={(e) => setF({ ...f, name: e.target.value })} />
      <input className="input" type="email" placeholder="Email" required
        onChange={(e) => setF({ ...f, email: e.target.value })} />
      <input className="input" type="password" placeholder="Password (min 6 chars)" required minLength={6}
        onChange={(e) => setF({ ...f, password: e.target.value })} />
      <button className="btn w-full">Register</button>
    </form>
  );
}
