'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, getUser } from '../lib/api';

export default function Reserve() {
  const [f, setF] = useState({ table_no: '', guests: '', reserve_time: '' });
  const [msg, setMsg] = useState({ text: '', ok: false });
  const [list, setList] = useState([]);
  const router = useRouter();

  const load = () => api('/reservations/mine').then((d) => Array.isArray(d) && setList(d));

  useEffect(() => {
    if (!getUser()) return router.push('/login');
    load();
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    const res = await api('/reservations', 'POST', {
      table_no: Number(f.table_no),
      guests: Number(f.guests),
      reserve_time: f.reserve_time,
    });
    if (res.id) {
      setMsg({ text: 'Table reserved!', ok: true });
      load();
    } else setMsg({ text: res.error, ok: false });
  };

  const cancel = async (id) => {
    await api(`/reservations/${id}/cancel`, 'PATCH');
    load();
  };

  return (
    <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
      <form onSubmit={submit} className="card space-y-3 h-fit">
        <h1 className="text-2xl font-bold">Reserve a Table</h1>
        <input className="input" type="number" min="1" placeholder="Table number" required
          onChange={(e) => setF({ ...f, table_no: e.target.value })} />
        <input className="input" type="number" min="1" placeholder="Number of guests" required
          onChange={(e) => setF({ ...f, guests: e.target.value })} />
        <input className="input" type="datetime-local" required
          onChange={(e) => setF({ ...f, reserve_time: e.target.value })} />
        <button className="btn w-full">Book Table</button>
        {msg.text && (
          <p className={`text-sm ${msg.ok ? 'text-green-600' : 'text-red-600'}`}>{msg.text}</p>
        )}
      </form>

      <div className="space-y-3">
        <h2 className="text-xl font-bold">My Reservations</h2>
        {list.length === 0 && <p className="text-gray-500">None yet.</p>}
        {list.map((r) => (
          <div key={r.id} className="card flex justify-between items-center">
            <div>
              <p className="font-semibold">Table {r.table_no} · {r.guests} guests</p>
              <p className="text-sm text-gray-500">{new Date(r.reserve_time).toLocaleString()}</p>
              <p className="text-xs">{r.status}</p>
            </div>
            {r.status === 'booked' && (
              <button onClick={() => cancel(r.id)} className="text-red-600 text-sm underline">
                Cancel
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
