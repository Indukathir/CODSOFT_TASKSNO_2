/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: { DEFAULT: '#0b3d91', dark: '#082b66', light: '#e8f0fb' },
      },
    },
  },
  plugins: [],
};
